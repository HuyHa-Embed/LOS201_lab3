# BÁO CÁO LAB-03: Debugging Kernel & Phân tích Hiệu năng Ứng dụng Nhúng

## 1. Thông tin sinh viên và môi trường

| Mục | Giá trị |
|---|---|
| Họ tên / MSSV | Hà Anh Huy / SE203732 (**kiểm tra lại trước khi nộp**) |
| Ngày thực hiện | 18/10/2026 |
| Host | Ubuntu 24.04, Linux 7.0.0-34-generic (PREEMPT_DYNAMIC), Intel i5-13420H, 12 luồng |
| Target | ARMv7-A Cortex-A9, QEMU vexpress-a9, kernel 5.15.0 (LAB-01), initramfs BusyBox |
| Toolchain | arm-linux-gnueabihf-gcc 13.3.0 |
| GDB | GNU gdb 15.1 (gdb-multiarch 15.1), gdbserver 9.2 (ARM, bản armhf của Ubuntu) |
| Valgrind / perf | Valgrind 3.22.0 / perf 7.0.14 |
| cyclictest / stress-ng | cyclictest 2.50 (rt-tests 2.5) / stress-ng 0.17.06 |

Ghi chú môi trường: máy không có quyền sudo không mật khẩu nên Valgrind, gdb-multiarch, cyclictest, gnuplot, stress-ng được tải `.deb` và giải nén cục bộ vào `~/embedded_lab3/tools/host` (không cài vào hệ thống). Gói `gdbserver` ARM không có sẵn cho Ubuntu 24.04 trên mirror đã dùng, nên dùng bản armhf 9.2; GDB 15.1 trên host vẫn giao tiếp bình thường qua giao thức RSP. `strace` ARM (6.19) cũng tải từ ports.ubuntu.com. Initramfs được đóng gói bằng `gen_init_cpio` (tạo device node không cần root), nên `output/initramfs_lab3.cpio.gz` boot được trên QEMU.

## 2. Phần A – GDB Remote Debug

Quy trình: QEMU `-nic user,model=lan9118,hostfwd=tcp::1234-:1234` → trong target `gdbserver 0.0.0.0:1234 /usr/bin/buggy_app` → host `gdb-multiarch` với `set architecture arm`, `set sysroot rootfs/initramfs`, `target remote localhost:1234`. (Dùng `0.0.0.0:1234`; khi để trống host, gdbserver báo "cannot resolve name" vì target không có DNS.) Toàn bộ log: `logs/gdb_session.txt`, lệnh: `logs/gdb_commands.gdb`.

| # | Bug | Vị trí | Giá trị tại thời điểm lỗi | Nguyên nhân kỹ thuật | Cách sửa |
|---|---|---|---|---|---|
| 1 | Array out-of-bounds | `buggy_app.c:8-9` (`process_data`) | `i == len == 5`, `&data[5] = 0x7efffd0c` nằm ngay sau `arr[4]` (0x7efffd08); `data[5] = 1084358912` (giá trị rác , lần chạy khác: -1032726272); `sum` đổi từ 150 thành 1084359062 | Điều kiện `i <= len` làm vòng lặp đọc thêm một phần tử ngoài mảng 5 phần tử (đọc stack liền kề) | Đổi thành `i < len` |
| 2 | Use after free | `buggy_app.c:18-19` (`create_message`) | Trước free: `buf=0x404198 "Hello Embedded Linux"`; sau free: cùng địa chỉ nhưng `x/s` = `"\004\004"`, 8 byte đầu bị allocator ghi đè (con trỏ tcache) → `main` in `Message: ` rỗng | Hàm trả về con trỏ đã `free()` (dangling pointer); allocator tái sử dụng vùng nhớ đó | Bỏ `free(buf)` trong hàm, trả về `buf` và để caller `free(msg)` (hoặc truyền buffer từ ngoài vào) |
| 3 | Integer overflow | `buggy_app.c:24` (`calculate`) | `a=b=100000`, `result=1410065408 (0x540be400)`, trong khi `(long long)a*b = 10000000000 (0x2540be400)`; lệnh `mul.w r3, r2, r3` chỉ giữ 32 bit thấp | `int * int` tràn vượt INT_MAX (2^31-1), kết quả bị cắt về 32 bit | Dùng `int64_t`/`long long` cho tích, hoặc kiểm tra tràn bằng `__builtin_mul_overflow` |

Điểm nổi bật từ phiên GDB (xem log đầy đủ trong `logs/gdb_session.txt`):

- `backtrace` tại bug 1: `#0 process_data (data=0x7efffcf8, len=5) at buggy_app.c:9`, `#1 0x00400774 in main (...) at buggy_app.c:35`.
- `info registers` tại điểm lỗi bug 1: `r0=0x7efffcf8 (data)`, `r1=r2=r3=5`, `sp=0x7efffcd0`, `lr=0x400775`, `pc=0x40068c <process_data+20>`, `cpsr=0x600f0030`.
- Watchpoint (`set can-use-hw-watchpoints 0` vì QEMU/kernel không có hw watchpoint) `watch sum`: `Old value = 150`, `New value = 1084359062` → chứng minh `data[5]` làm hỏng tổng.
- **Sửa bug trong runtime** bằng `set variable sum = 150` và `set variable len = 4` rồi `finish`: chương trình in `Sum = 150` (log QEMU: `logs/qemu_part_a.txt`).
- Bug 3: `disassemble` cho thấy `mul.w r3, r2, r3`; `print/x` hai giá trị 0x540be400 và 0x2540be400 cho thấy phần cao 0x2 bị mất.

## 3. Phần B – Memory Analysis (Valgrind)

`leaky_app` (x86_64, `-g -O0`) chạy `valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes` (log: `logs/valgrind_report.txt`).

```
HEAP SUMMARY:
    in use at exit: 16,900 bytes in 250 blocks
  total heap usage: 352 allocs, 102 frees, 24,196 bytes allocated
LEAK SUMMARY:
   definitely lost: 16,900 bytes in 250 blocks
   indirectly lost: 0 bytes in 0 blocks
     possibly lost: 0 bytes in 0 blocks
ERROR SUMMARY: 3 errors from 3 contexts
```

Allocation stack trace của 3 leak (bản dòng thực tế trong `leaky_app.c`):

| Leak | Kích thước | Stack (từ malloc lên main) | Vì sao không được free |
|---|---|---|---|
| `r->scores` | 2,000 B / 100 block | `malloc` ← `create_record (leaky_app.c:35)` ← `main (:70)` | `delete_record()` chỉ `free(r)`, thiếu `free(r->scores)` |
| `r->name` | 2,100 B / 100 block | `malloc` ← `create_record (:33)` ← `main (:70)` | `delete_record()` thiếu `free(r->name)` |
| `buf` | 12,800 B / 50 block | `malloc` ← `process_messages (:53)` ← `main (:78)` | Mỗi vòng lặp cấp phát 256 B nhưng thiếu `free(buf)` |

Sau khi sửa (`leaky_app_fixed`, bật free bằng `-DFIXED`; log `logs/valgrind_fixed.txt`):

```
total heap usage: 352 allocs, 352 frees, 24,196 bytes allocated
All heap blocks were freed -- no leaks are possible
ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

**VmRSS trong QEMU** (B.5). Ứng dụng ARM tự đọc `/proc/self/status` trước và sau khi chạy (build `-DMEMSTAT`, tăng số message lên 4000 để thấy rõ; vì với 50 message mức tăng quá nhỏ và bộ đếm RSS của kernel cập nhật theo lô nên không hiện ra):

| Chương trình | VmSize trước | VmSize sau | VmRSS trước | VmRSS sau |
|---|---|---|---|---|
| `leaky_app_arm` (có leak) | 1548 kB | 2472 kB | 156 kB | **1964 kB** |
| `leaky_app_arm_fixed` (đã sửa) | 1548 kB | 1548 kB | 156 kB | **156 kB** |

Memory map của một process đang chạy (`/proc/PID/maps`, ví dụ `sleep`): text/rodata/data của `/bin/busybox` tại 0x00010000–0x00187000, `[heap]` 0x00187000–0x001ad000, `[stack]` 0x7e8c6000, rồi `[sigpage]`, `[vvar]`, `[vdso]`, `[vectors]` 0xffff0000.

## 4. Phần C – Profiling

### strace -c (host x86_64, `logs/strace_summary.txt`; tổng 120 syscall)

| Hạng | syscall | % time | calls |
|---|---|---|---|
| 1 | munmap | 64.47 | 3 |
| 2 | close | 31.73 | 4 |
| 3 | write | 3.05 | 70 |
| 4 | openat | 0.51 | 4 |
| 5 | fstat | 0.25 | 5 |

### strace -c (ARM QEMU; tổng 120 syscall)

| Hạng | syscall | % time | calls |
|---|---|---|---|
| 1 | execve | 46.41 | 1 |
| 2 | munmap | 20.36 | 2 |
| 3 | write | 17.51 | 75 |
| 4 | brk | 10.88 | 3 |
| 5 | access | 1.49 | 1 |

Nhận xét: tổng cả hai chỉ ~120 syscall và < 13 ms; I/O ghi 10000 dòng chỉ cần 70–75 `write` nhờ stdio buffer 4 KB, nên **I/O không phải bottleneck**. Thời gian chạy: host `real 0.043 s`, ARM QEMU `real 1.38 s` (chậm ~32 lần do mô phỏng TCG, không phải do ARM thật).

### perf (host, `logs/perf_report.txt`, `logs/perf_stat.txt`)

`perf record -F 20000 -g` (cycles, 862 mẫu trên P-core):

| Hạng | Overhead | Hàm | Shared object |
|---|---|---|---|
| 1 | 62.50% | `__ieee754_log_fma` | libm.so.6 |
| 2 | 22.04% | `heavy_compute` | perf_target |
| 3 | 8.09% | `log` | libm.so.6 |
| 4 | 1.55% | `__log_finite@plt` | libm.so.6 |
| 5 | 0.59% | `log@plt` | perf_target |

`perf stat` (P-core): task-clock 35–39 ms, 369 M instructions / 77.7 M cycles ≈ **4.7–4.9 IPC**, branch-misses 9.7 k trên 50.7 M branches (≈0,02%), cache-misses 41 k. IPC cao và rất ít miss cho thấy mã bị giới hạn bởi tính toán, không phải bộ nhớ. Flame graph: `logs/flamegraph.svg`.

**Kết luận:** bottleneck của `perf_target` là **CPU** (~93% trong `heavy_compute` + `log`), không phải I/O. Tối ưu: (1) thay `log(x+1.0)` bằng `log1p` hoặc tính trước bảng; (2) vector hoá bằng NEON/SIMD, `-O3 -ffast-math`; (3) loop-invariant: `heavy_compute` trên cùng `darr` được gọi 50 lần với kết quả giống nhau → tính một lần rồi nhân. `linear_search` không đáng kể trong profile.

## 5. Phần D – Real-Time Latency (host, standard kernel)

Điều kiện: `cyclictest --mlockall --threads=4 --priority=80 --interval=1000 --distance=500 --loops=10000 --histogram=200`, đồng thời `stress-ng --cpu 12 --io 4 --vm 2 --vm-bytes 256M --timeout 40s`.

| Chỉ số | Standard Kernel (kết quả thực tế) |
|---|---|
| Min latency | 2–3 µs |
| Avg latency | 3–4 µs |
| Max latency | 132 / 144 / 133 / 150 µs (thread 0–3) → tối đa **150 µs** |
| Overrun (histogram overflow) | 0 |
| Kernel version | 7.0.0-34-generic #34~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC |
| PREEMPT config | `CONFIG_PREEMPT_DYNAMIC=y`, `CONFIG_PREEMPT_LAZY=y`, `# CONFIG_PREEMPT is not set`, `# CONFIG_PREEMPT_RT is not set` |
| CPU load khi đo | stress-ng (cpu+io+vm) |

Thống kê histogram: 99,92% mẫu < 50 µs, 99,53% ≤ 10 µs. Biểu đồ: `logs/latency_histogram.png` (trục Y thang log). Dữ liệu: `logs/hist_standard.txt`.

![Histogram latency cyclictest](../logs/latency_histogram.png)

Ghi chú trung thực: kernel host 7.0 là bản mới, đã có nhiều cải tiến preemption (PREEMPT_DYNAMIC/LAZY) nên số đo tốt hơn nhiều so với khoảng "~100–2000 µs" trong đề; avg 3–4 µs nhờ CPU hiện đại. Phần so sánh với RT/lowlatency kernel làm ở mức lý thuyết (cài kernel khác cần reboot và quyền root, đề cho phép).

**Tại sao Max quan trọng hơn Avg:** hệ thống real-time bị đánh giá theo deadline xấu nhất. Một lần trễ 150 µs có thể làm hỏng chu kỳ điều khiển dù 99,9% lần khác chỉ 3 µs; trung bình che giấu các spike hiếm nhưng gây lỗi.

**PREEMPT_RT giảm Max latency thế nào:** biến phần lớn hard IRQ handler thành kernel thread có thể bị preempt và có priority; thay spinlock bằng rt_mutex (có priority inheritance, ngủ được) nên vùng không thể preempt gần như biến mất; softirq chạy trong thread; high-resolution timer chuẩn xác. Nhờ đó tác vụ priority cao có thể giành CPU ngay cả khi kernel đang xử lý ngắt/giữ lock.

**Robot yêu cầu phản hồi < 500 µs:** nên dùng PREEMPT_RT (hoặc ít nhất lowlatency + CPU isolation `isolcpus`, `nohz_full`). Standard kernel có thể đạt số đo tốt như trên, nhưng không **đảm bảo** worst-case giới hạn trên (spike hàng ms có thể xảy ra với driver/IO nặng); RT cho giới hạn trên có thể chứng minh và kiểm thử được.

## 6. Trả lời câu hỏi phân tích

**Câu 1.** Khi gõ `next` trong GDB: GDB host xác định địa chỉ lệnh/dòng tiếp theo từ debug info, đặt breakpoint tạm (hoặc single-step) bằng các gói RSP (`Z0`/`s`/`vCont;s`/`c`) gửi qua TCP (port 1234 → QEMU hostfwd → guest). `gdbserver` trong target dùng `ptrace(PTRACE_SINGLESTEP/CONT)` điều khiển tiến trình, chờ `waitpid` báo dừng (SIGTRAP), đọc thanh ghi/bộ nhớ (`g`, `m`) và trả gói stop-reply `T05...` về host; GDB cập nhật dòng source và biến hiển thị. Giao thức: GDB Remote Serial Protocol (RSP), gói `$data#checksum`, chạy trên TCP. Cần `gdb-multiarch` vì GDB thường chỉ được build cho kiến trúc host x86_64, không hiểu thanh ghi/ISA ARM (`set architecture arm` không tồn tại ở `gdb` thường – đã kiểm tra: "Undefined item: arm").

**Câu 2.** *Definitely lost*: không còn con trỏ nào trỏ tới khối (hoặc tới bên trong khối) đó. *Indirectly lost*: khối chỉ còn được trỏ bởi một khối khác đã bị definitely lost (ví dụ struct cha bị leak, con trỏ con nằm trong nó). Trong `leaky_app`, `r->name`/`r->scores` được báo **definitely lost** (không phải indirectly), vì `free(r)` đã giải phóng struct cha → không có khối cha nào bị leak, và không còn con trỏ nào tới name/scores (kết quả thực tế: indirectly lost = 0). Chúng chỉ là *indirectly lost* nếu bản thân `Record` cũng bị leak. Ngoài leak, Valgrind phát hiện: đọc/ghi ngoài vùng heap (invalid read/write), dùng sau khi free, double free / free sai con trỏ, dùng giá trị chưa khởi tạo (conditional jump depends on uninitialised value), overlap trong `memcpy`/`strcpy`, mismatch `malloc/delete`.

**Câu 3.** (1) **NEON SIMD** (Cortex-A9 có NEON): xử lý 4 float/lệnh; NEON chỉ hỗ trợ float 32-bit nên cần đổi `double`→`float` và dùng xấp xỉ `log`/`sqrt` (vd. `vrsqrteq_f32`, polynomial log); ước tính tăng 2–4× cho phần tính toán. (2) **Loop unrolling + bỏ phụ thuộc chuỗi** (nhiều accumulator): tăng ILP, giảm chi phí nhánh; ước tính 1,2–1,5×. (3) **Cache locality / hoisting**: duyệt tuần tự đã tốt; có thể tính `log(arr[i]+1)` một lần/bảng tra vì kết quả lặp 50 lần → giảm ~50× tổng thời gian trong benchmark này. (4) `-O3 -ffast-math` hoặc `log1p` giảm chi phí hàm thư viện (1,1–1,3×).

**Câu 4.** Nguyên nhân spike trong standard kernel: (a) **interrupt handling**: hard IRQ và softirq không bị preempt, chặn tác vụ ưu tiên cao; (b) **scheduler/vùng non-preemptible**: spinlock và `preempt_disable()` giữ CPU, thread RT phải chờ thoát vùng đó; (c) **memory management**: page fault, reclaim, compaction, lock mm; (d) cache/TLB/migrate SMT, thay đổi tần số CPU. PREEMPT_RT: (a) threaded IRQ + softirq trong thread có priority, bị preempt được; (b) spinlock → rt_mutex ngủ được với priority inheritance, giảm vùng non-preemptible; (c) kết hợp `mlockall` và cấu hình allocator để tránh page fault ở đường dẫn quan trọng; high-res timer cho wake-up chính xác.

**Câu 5.** (a) Crash ngẫu nhiên sau vài giờ → **GDB** (core dump/`catch signal SIGSEGV`, backtrace) và Valgrind để tìm lỗi bộ nhớ gây ra. (b) Chạy chậm dần theo thời gian → **Valgrind** (memcheck: memory leak) và theo dõi VmRSS; strace nếu nghi fd/syscall tích tụ. (c) Thỉnh thoảng trễ deadline → **cyclictest** (đo worst-case latency/histogram). (d) Một hàm làm cả hệ thống chậm → **perf** (hotspot, flame graph); strace nếu hàm đó chủ yếu gọi syscall.

## 7. Nhận xét & Khó khăn

1. **Thiếu quyền sudo/công cụ**: không cài được gói bằng apt. Giải quyết: `apt-get download` + `dpkg -x` vào thư mục cục bộ, đặt `LD_LIBRARY_PATH`/`VALGRIND_LIB`; phần cần root (perf, cyclictest SCHED_FIFO) chạy bằng một script `tools/run_root_parts.sh` với `sudo`.
2. **Không có gdbserver ARM và `arm-linux-gnueabihf-g++`**: build gdbserver 15.1 từ source thất bại (cần C++ cross compiler). Giải quyết: dùng gói `gdbserver` armhf 9.2 từ ports.ubuntu.com, chép thư viện (`ld-linux`, libc, libstdc++, libgcc_s…) từ toolchain vào initramfs.
3. **`gdbserver :1234` lỗi "cannot resolve name"** trong target (không có DNS): dùng `0.0.0.0:1234`; NIC của vexpress dùng `-nic user,model=lan9118` thay vì virtio.
4. **`-mfloat-abi=hard` báo "architecture lacks an FPU"** nếu thiếu `-mfpu=neon-vfpv3`: thêm cờ này.
5. **VmRSS không đổi** khi chỉ leak ~24 KB (bộ đếm RSS của kernel cập nhật theo lô): tăng tải leak lên 4000 message để quan sát.
6. Giới hạn: không đo được so sánh lowlatency/RT kernel thực tế; `perf` không có trên target ARM nên phần perf chỉ làm trên host.
